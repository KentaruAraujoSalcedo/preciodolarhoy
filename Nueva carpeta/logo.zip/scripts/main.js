// ==============================
// File: scripts/main.js
// ==============================
import { state, setState } from './state.js';
import { cargarTasas, cargarSunatDesdeTasas, cargarHistorico } from './data.js';
import { initStaticUI, bindEvents, renderTabla, renderSunat, renderResultadoConversor } from './ui.js';
import { renderGraficoHistorico } from './chart.js';

window.addEventListener('DOMContentLoaded', init);

async function init() {
  try {
    initStaticUI();

    // Estado inicial desde DOM
    const modoIni = document.querySelector('input[name="modo"]:checked')?.value || 'recibir';
    const monedaTengoIni = document.getElementById('moneda-tengo')?.value || 'USD';
    const monedaQuieroIni = document.getElementById('moneda-quiero')?.value || 'PEN';

    setState({ modo: modoIni, monedaTengo: monedaTengoIni, monedaQuiero: monedaQuieroIni });

    await cargarTasas();
    await cargarSunatDesdeTasas();

    renderSunat();
    renderTabla();
    renderResultadoConversor();

    // Gráfico histórico
    try {
      const ultimos7 = await cargarHistorico();
      renderGraficoHistorico(ultimos7);
    } catch (e) {
      console.warn('No se pudo cargar el histórico:', e);
    }

    // Eventos reactivos
    bindEvents({ onChange: () => {
      renderResultadoConversor();
      renderTabla(); // reordena según modo/monedas y recalcula celdas
    }});

  } catch (e) {
    console.error('Error inicializando la app:', e);
  }
}
